<?php require_once('Connections/connect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php

// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}



if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE users SET name=%s, shopname=%s, address=%s, phone_number=%s, pass=%s WHERE id=%s",
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['shopname'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['phone_number'], "text"),
                       GetSQLValueString($_POST['pass'], "text"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($updateSQL, $connect) or die(mysql_error());

  $updateGoTo = "updated.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$maxRows_users = 1;
$pageNum_users = 0;
if (isset($_GET['pageNum_users'])) {
  $pageNum_users = $_GET['pageNum_users'];
}
$startRow_users = $pageNum_users * $maxRows_users;

$colname_users = "-1";
if (isset($_GET['id'])) {
  $colname_users = $_GET['id'];
}
mysql_select_db($database_connect, $connect);
$query_users = sprintf("SELECT * FROM users WHERE id = %s", GetSQLValueString($colname_users, "int"));
$query_limit_users = sprintf("%s LIMIT %d, %d", $query_users, $startRow_users, $maxRows_users);
$users = mysql_query($query_limit_users, $connect) or die(mysql_error());
$row_users = mysql_fetch_assoc($users);

if (isset($_GET['totalRows_users'])) {
  $totalRows_users = $_GET['totalRows_users'];
} else {
  $all_users = mysql_query($query_users);
  $totalRows_users = mysql_num_rows($all_users);
}
$totalPages_users = ceil($totalRows_users/$maxRows_users)-1;
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DASHBOARD PROFILE</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
    
</head>

<body>
    <div>
        <nav class="navbar navbar-light navbar-expand-md sticky-top navigation-clean-button" style="height:80px;background-color:#f00;color:#ffffff;">
            <div class="container-fluid"><a class="navbar-brand" href="#"><i class="fa fa-globe"></i>&nbsp;Chief Tailor</a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="dashboard" style="color:#ffffff;"><i class="fa fa-home"></i>&nbsp;Home</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="profile.php?id=<?php echo $row_users['id']; ?>" style="color:#ffffff;"><i class="fa fa-user"></i>&nbsp;Profile</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="male-m.php" style="color:#ffffff;"><i class="fa fa-avatar"></i>&nbsp;Male Measurement</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="female-m.php" style="color:#ffffff;"><i class="fa fa-user-circle-o"></i>&nbsp;Female Measurement</a></li>
                        <li class="nav-item" role="presentation"><a href="<?php echo $logoutAction ?>" style="color:#FFF;" class="nav-link"><i class="fa fa-sign-out"></i>Log out</a></li>
                    </ul>
            </div>
    </div>
    </nav>
    </div>
    <main class="page landing-page">
        <section class="clean-block clean-hero" style="background-image:url(&quot;assets/img/tech/tailor.jpg&quot;);color:rgba(9, 162, 255, 0.85);">
            <div class="text">
                <h2>Welcome <?php echo $row_users['name']; ?>.</h2>
                <div class=" text-white">
                <h2>Profile</h2>
               <div class="alert alert-success alert-dismissible">Record updated</div>
             
               
                 <br>
                <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
                  <div class="input-group">
                  
                  <div class="input-group-prepend"><span class="input-group-text">Name</span></div><input type="text" name="name" value="<?php echo htmlentities($row_users['name'], ENT_COMPAT, 'utf-8'); ?>"  class="form-control"></div><br>
                     <div class="input-group">
                  
                  <div class="input-group-prepend"><span class="input-group-text">Shop Name</span></div>
                      <input type="text" name="shopname" value="<?php echo htmlentities($row_users['shopname'], ENT_COMPAT, 'utf-8'); ?>" class="form-control"></div><br>
                    <div class="input-group">
                  
                  <div class="input-group-prepend"><span class="input-group-text">Adress</span></div>
                      <input type="text" name="address" value="<?php echo htmlentities($row_users['address'], ENT_COMPAT, 'utf-8'); ?>" class="form-control"></div><br>
                   <div class="input-group">
                  
                  <div class="input-group-prepend"><span class="input-group-text">Number</span></div>
                      <input type="text" name="phone_number" value="<?php echo htmlentities($row_users['phone_number'], ENT_COMPAT, 'utf-8'); ?>" s class="form-control"></div><br>
                     <div class="input-group">
                  
                  <div class="input-group-prepend"><span class="input-group-text">Password</span></div>
                      <input type="password" name="pass" value=""  class="form-control"></div><br>
                    
                      <input type="submit" value="Update Profile" class="btn btn-outline-danger">
                  
                  <input type="hidden" name="MM_update" value="form1">
                  <input type="hidden" name="id" value="<?php echo $row_users['id']; ?>">
                </form>
                <p>&nbsp;</p>
        </section>
        <h1></h1>
             <section class="clean-block slider dark"></section>
        
    </main>
    <footer class="page-footer bg-success">
    <h2 class="text-center header-standard text-white">Our Advertisers</h2>
        <div class="container">
         <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="assets/img/tech/3.jpg" alt="First slide" style="height:250px; width: 100%;">
        <div class="carousel-caption d-none d-md-block">
            <h1>First caption</h1>
            <p></p>
        </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/img/tech/1.jpg" alt="Second slide" style="height:250px; width: 100%;">        
        <div class="carousel-caption d-none d-md-block">
            <h1>Second caption</h1>
            <p></p>
        </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/img/tech/2.jpg" alt="Third slide" style="height:250px; width: 100%;">        
        <div class="carousel-caption d-none d-md-block">
            <h1>Third caption</h1>
            <p></p>
        </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
       </div>
            </div>
        </div>
        <div class="footer-copyright">
            <p>© 2018 Copyright Text</p>
        </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>
<?php
mysql_free_result($users);
?>
