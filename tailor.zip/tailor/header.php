<div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="index.php" style="color:#ffffff;"><i class="fa fa-home"></i>&nbsp;Home</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="about.php" style="color:#ffffff;"><i class="fa fa-wpexplorer"></i>&nbsp;About Us</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#" style="color:#ffffff;"><i class="fa fa-star-o"></i>&nbsp;Features</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="signup.php" style="color:#ffffff;"><i class="fa fa-user-pencil"></i>&nbsp;Register</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="login.php" style="color:#ffffff;"><i class="fa fa-sign-in"></i>&nbsp;Sign In</a></li>
                    </ul>
            </div>