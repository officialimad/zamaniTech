<?php require_once('Connections/connect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "login.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php

// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}



if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_users = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_users = $_SESSION['MM_Username'];
}
mysql_select_db($database_connect, $connect);
$query_users = sprintf("SELECT * FROM users WHERE phone_number = %s", GetSQLValueString($colname_users, "text"));
$users = mysql_query($query_users, $connect) or die(mysql_error());
$row_users = mysql_fetch_assoc($users);
$totalRows_users = mysql_num_rows($users);

$maxRows_female = 10;
$pageNum_female = 0;
if (isset($_GET['pageNum_female'])) {
  $pageNum_female = $_GET['pageNum_female'];
}
$startRow_female = $pageNum_female * $maxRows_female;

$colname_female = "-1";
if (isset($_POST['txt_search'])) {
  $colname_female = $_POST['txt_search'];
}
mysql_select_db($database_connect, $connect);
$query_female = sprintf("SELECT * FROM femalem WHERE phone = %s", GetSQLValueString($colname_female, "text"));
$query_limit_female = sprintf("%s LIMIT %d, %d", $query_female, $startRow_female, $maxRows_female);
$female = mysql_query($query_limit_female, $connect) or die(mysql_error());
$row_female = mysql_fetch_assoc($female);

if (isset($_GET['totalRows_female'])) {
  $totalRows_female = $_GET['totalRows_female'];
} else {
  $all_female = mysql_query($query_female);
  $totalRows_female = mysql_num_rows($all_female);
}
$totalPages_female = ceil($totalRows_female/$maxRows_female)-1;
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DASHBOARD FEMALE</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
    
</head>

<body>
    <div>
        <nav class="navbar navbar-light navbar-expand-md sticky-top navigation-clean-button" style="height:80px;background-color:#f00;color:#ffffff;">
            <div class="container-fluid"><a class="navbar-brand" href="#"><i class="fa fa-globe"></i>&nbsp;Chief Tailor</a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="dashboard" style="color:#ffffff;"><i class="fa fa-home"></i>&nbsp;Home</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" style="color:#ffffff;"><i class="fa fa-user"></i>&nbsp;Profile</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="male-m.php" style="color:#ffffff;"><i class="fa fa-avatar"></i>&nbsp;Male Measurement</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="female-m.php" style="color:#ffffff;"><i class="fa fa-user-circle-o"></i>&nbsp;Female Measurement</a></li>
                        <li class="nav-item" role="presentation"><a href="<?php echo $logoutAction ?>" style="color:#FFF;" class="nav-link"><i class="fa fa-sign-out"></i>Log out</a></li>
                    </ul>
            </div>
    </div>
    </nav>
    </div>
    <main class="page landing-page">
        <section class="clean-block clean-hero" style="background-image:url(&quot;assets/img/tech/tailor.jpg&quot;);color:rgba(9, 162, 255, 0.85);">
            <div class="text">
                <h2>Welcome <?php echo $row_users['name']; ?>.</h2>
                <div class=" text-white">
                 
                <form name="txt_search" id="txt_search" method="post" action="search-result-m.php">
      <div class="input-group">
      <input type="text" name="txt_search" id="txt_search"  PLACEHOLDER="Enter phone number" class=" form-control" />
      
                
                <div class="input-group-append"><input type="submit" name="btn_search" id="btn_search" value="GO" class="btn btn-danger" /></div></div><br>
                </form>
                 <br>
                 <table class="table">
                   <tr>
                    
                   </tr>
                   <?php do { ?>
                     <tr>
                       
                       <td>Name</td><td><?php echo $row_female['name']; ?></td></tr>
                       <tr><td>Phone Number</td><td><?php echo $row_female['phone']; ?></td></tr>
                       <tr><td>Adress</td><td><?php echo $row_female['address']; ?></td></tr>
                       <tr><td>Bust Size</td><td><?php echo $row_female['bust']; ?></td></tr>
                       <tr><td>Waist Size</td><td><?php echo $row_female['waist']; ?></td></tr>
                       <tr><td>Shoulder Size</td><td><?php echo $row_female['shoulder']; ?></td></tr>
                       <tr><td>Under Bust Size</td><td><?php echo $row_female['underbust']; ?></td></tr>
                       <tr><td>BustPand Size</td><td><?php echo $row_female['bustpand']; ?></td></tr>
                       <tr><td>BustPoint Size</td><td><?php echo $row_female['bustpoint']; ?></td></tr>
                       <tr><td>BluesLength Size</td><td><?php echo $row_female['blueslength']; ?></td></tr>
                       <tr><td>Niple Size</td><td><?php echo $row_female['niple']; ?></td></tr>
                       <tr><td>Acfrount Size</td><td><?php echo $row_female['acfrount']; ?></td></tr>
                       <tr><td>Acback Size</td><td><?php echo $row_female['acback']; ?></td></tr>
                       <tr><td>Shwaist Size</td><td><?php echo $row_female['shwaits']; ?></td></tr>
                       <tr><td>Shhips Size</td><td><?php echo $row_female['shhips']; ?></td></tr>
                       <tr><td>ShortSleeve Size</td><td><?php echo $row_female['shortsleeve']; ?></td></tr>
                       <tr><td>LongSleeve Size</td><td><?php echo $row_female['longsleeve']; ?></td></tr>
                       <tr><td>ThreeCutter Size</td><td><?php echo $row_female['threecutter']; ?></td></tr>
                       <tr><td>SkateWaist Size</td><td><?php echo $row_female['skatewaist']; ?></td></tr>
                       <tr><td>Hips Size</td><td><?php echo $row_female['hips']; ?></td></tr>
                       <tr><td>Skate Length</td><td><?php echo $row_female['skatelength']; ?></td></tr>
                       <tr><td>Footstep Size</td><td><?php echo $row_female['footstep']; ?></td></tr>
                       <tr><td>Gown Length</td><td><?php echo $row_female['gwonlength']; ?></td></tr>
                       <tr><td>Date Registered</td><td><?php echo $row_female['date']; ?></td>
                     </tr>
                     <?php } while ($row_female = mysql_fetch_assoc($female)); ?>
                 </table>
<br>
              
        </section>
        <h1></h1>
      
        <section class="clean-block slider dark"></section>
            </main>
    <footer class="page-footer bg-success">
    <h2 class="text-center header-standard text-white">Our Advertisers</h2>
        <div class="container">
         <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="assets/img/tech/3.jpg" alt="First slide" style="height:250px; width: 100%;">
        <div class="carousel-caption d-none d-md-block">
            <h1>First caption</h1>
            <p></p>
        </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/img/tech/1.jpg" alt="Second slide" style="height:250px; width: 100%;">        
        <div class="carousel-caption d-none d-md-block">
            <h1>Second caption</h1>
            <p></p>
        </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/img/tech/2.jpg" alt="Third slide" style="height:250px; width: 100%;">        
        <div class="carousel-caption d-none d-md-block">
            <h1>Third caption</h1>
            <p></p>
        </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
       </div>
            </div>
        </div>
        <div class="footer-copyright">
            <p>© 2018 Copyright Text</p>
        </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>
<?php
mysql_free_result($users);

mysql_free_result($female);
?>
