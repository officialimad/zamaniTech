<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO users (name, shopname, phone_number, pass) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['shopname'], "text"),
                       GetSQLValueString($_POST['phone_number'], "text"),
                       GetSQLValueString($_POST['pass'], "text"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($insertSQL, $connect) or die(mysql_error());

  $insertGoTo = "success.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WELCOME TO CHEIF TAILOR SIGNUP</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
    <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
    <link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css">
    <link href="SpryAssets/SpryValidationConfirm.css" rel="stylesheet" type="text/css">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationConfirm.js" type="text/javascript"></script>
</head>

<body>
    <div>
        <nav class="navbar navbar-light navbar-expand-md sticky-top navigation-clean-button" style="height:80px;background-color:#F00;color:#ffffff;">
            <div class="container-fluid"><a class="navbar-brand" href="#"><i class="fa fa-globe"></i>&nbsp;Chief Tailor</a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <?php include'header.php'; ?>
    </div>
    </nav>
    </div>
    <main class="page landing-page">
        <section class="clean-block clean-hero" style="background-image:url(&quot;assets/img/tech/tailor.jpg&quot;);color:rgba(9, 162, 255, 0.85);">
            <div class="text">
               <div class="alert alert-dismissible alert-success">Account Created Successful</div>
                <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
                  <span id="sprytextfield1">
                  <div class="input-group">
                    <div class="input-group-prepend"><span class="input-group-text">Tailor Name</span></div>
                    
                    <input type="text" name="name" value="" class="form-control"><span class="textfieldRequiredMsg">Tailor is required.</span>
                  </div></span><br>
                  <span id="sprytextfield2">
                  <div class="input-group">
                    <div class="input-group-prepend"><span class="input-group-text">Shop Name</span></div>
                   
                    <input type="text" name="shopname" value="" class="form-control"><span class="textfieldRequiredMsg">Shop name  is required.</span>
                    </div></span>
                    <br>
                  <span id="sprytextfield3">
                  <div class="input-group">
                    <div class="input-group-prepend"><span class="input-group-text">Phone No</span></div>
                    <input type="text" name="phone_number" value="" class="form-control">
                  <span class="textfieldRequiredMsg">Phone Number is required.</span><span class="textfieldInvalidFormatMsg">Only phone number is accepted.</span></div></span>
                    <br>
                       <span id="sprypassword1">
                  <div class="input-group">
                    <div class="input-group-prepend"><span class="input-group-text">Password</span></div>
                 
                    <input type="password" name="pass" value="" class="form-control"  id="pass2">
                    <span class="passwordRequiredMsg">Password is required.</span><span class="passwordMinCharsMsg">Password must be 8 characters.</span></span></div><br>
                      
                      
                 
                  <span id="spryconfirm1">
                 
                  <div class="input-group">
                    <div class="input-group-prepend"><span class="input-group-text">Comfirm</span></div>
                  <input type="password" name="pass2" id="pass" class="form-control">
                  <span class="confirmRequiredMsg">A value is required.</span><span class="confirmInvalidMsg">The values don't match.</span></span></div><br>
                    
                      <input type="submit" value="Register" class="btn btn-outline-light btn-lg"></td>
                   
                  <input type="hidden" name="MM_insert" value="form1">
                </form>
                <p>&nbsp;</p>
Already have an account <a href="login.php">login here</a>
        </section>
       <footer class="bg-dark text-white text-center">
       
        <div class="footer-copyright">
            <p>© 2018 Copyright Text</p>
        </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.min.js"></script>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {validateOn:["blur", "change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {validateOn:["blur", "change"]});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "real", {validateOn:["blur", "change"]});
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1", {validateOn:["change"], minChars:8});
var spryconfirm1 = new Spry.Widget.ValidationConfirm("spryconfirm1", "pass2", {validateOn:["blur", "change"]});
</script>
</body>

</html>